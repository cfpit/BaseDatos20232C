-- 43. Listar la mitad de los empleados. 
SET @inicio=0; SET @cantidadRegistros=(select (count(*) div 2 + 1) from employee);
PREPARE sentencia FROM 'SELECT * FROM employee LIMIT ? , ?';
EXECUTE sentencia USING @inicio, @cantidadRegistros;

select * from employee;-- 43
select * from employee limit 5;
select * from employee limit 5, 3;

-- 45.	Listar todos los libros cuyo precio sea inferior al precio promedio 
-- de todos los libros. 
select avg(price) from titles;-- 14,76 U$s

select 	*
from	titles
where	price < (select avg(price) from titles);

-- 48.	Listar todos los comprobantes de ventas emitidos para la venta 
-- del libro "Sushi, Anyone?". No utilizar relaciones. 
-- por join:
select		s.ord_num 'comprobante de venta',
			t.title libro
from		sales s
inner join	titles t on (t.title_id = s.title_id)
where		t.title like '%sushi%any%';

-- por subquery
select		ord_num 'comprobante de venta' 
from		sales
where		title_id in (
							select 	title_id 
                            from 	titles 
                            where 	title like '%sushi%any%'
						);

-- 47.	Listar la cantidad de libros vendidos por cada tienda, sólo de 
-- aquellas tiendas que su cantidad de venta sea mayor al promedio de 
-- venta general. 
select		st.stor_name as libreria,
			sum(s.qty) ventas
from		sales s
inner join	stores st on st.stor_id = s.stor_id
group by	st.stor_name
having		sum(qty) > (select sum(qty)/count(distinct stor_id) from sales)
order by	2 desc;

select sum(qty) from sales;-- 348
select count(distinct stor_id) from sales;-- 6

-- 50. Listar título del libro, categoría de precio, precio unitario y cantidad 
-- ejemplares vendidos. Mostrar sólo aquellos libros que sean económicos y cuya 
-- cantidad de ejemplares vendidos sea mayor a cero. Se deben apodar las columnas 
-- de la siguiente manera: 'Tít", "Cat", "Pr", "Cant". La categoría de los precios 
-- es la misma del ejercicio 41.
	
select	*
from	(
			SELECT	t.title libro,
					t.price precio,
					(case 
						when price < 10 then 'Economica'
						when price between 10 and 20 then 'Normal'
						when price > 20 then 'Cara'
						else 'Sin categorizar'
					end) as categoria,
					s.qty ventas
			FROM		titles t
			INNER JOIN	sales s on (t.title_id = s.title_id)
            WHERE		s.qty > 0
        ) as misubconsulta
where	misubconsulta.categoria = 'Economica';
		

        





















